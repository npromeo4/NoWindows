# Global Imports
import json
from collections import defaultdict

# Metaparser
from genie.metaparser import MetaParser

# =============================================
# Collection for '/mgmt/tm/ltm/monitor/sip' resources
# =============================================


class LtmMonitorSipSchema(MetaParser):

    schema = {}


class LtmMonitorSip(LtmMonitorSipSchema):
    """ To F5 resource for /mgmt/tm/ltm/monitor/sip
    """

    cli_command = "/mgmt/tm/ltm/monitor/sip"

    def rest(self):

        response = self.device.get(self.cli_command)

        response_json = response.json()

        if not response_json:
            return {}

        return response_json
