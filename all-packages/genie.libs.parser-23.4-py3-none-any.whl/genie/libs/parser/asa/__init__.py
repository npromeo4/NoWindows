from genie.base import *
from genie import abstract

abstract.declare_token(__name__)
