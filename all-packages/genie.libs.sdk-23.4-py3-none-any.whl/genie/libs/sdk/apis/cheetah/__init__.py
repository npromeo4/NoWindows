from genie import abstract

abstract.declare_package(__name__)
