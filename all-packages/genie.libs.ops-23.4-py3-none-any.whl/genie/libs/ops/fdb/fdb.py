from genie.ops.base import Base

class Fdb(Base):
    exclude = []