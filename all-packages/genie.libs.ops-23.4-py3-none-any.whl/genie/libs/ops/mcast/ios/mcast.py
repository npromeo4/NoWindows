'''
Mcast Genie Ops Object for IOS - CLI.
'''
from ..iosxe.mcast import Mcast as McastXE

class Mcast(McastXE):
    pass