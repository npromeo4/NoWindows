# Genie
from genie.ops.base import Base


class Isis(Base):

    exclude = []