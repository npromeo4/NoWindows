from genie.libs.ops.isis.iosxe.isis import Isis as IsisXE

class Isis(IsisXE):
	'''Isis Genie Ops Object'''
	pass