# super class
from genie.libs.ops.msdp.iosxe.msdp import Msdp as MsdpXE

class Msdp(MsdpXE):
    '''
        Msdp Ops Object
    '''
    pass