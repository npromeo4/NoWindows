'''
Lisp Genie Ops Object for IOS - CLI
'''
from ..iosxe.lisp import Lisp as LispXE

class Lisp(LispXE):
    pass