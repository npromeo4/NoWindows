'''
Lldp Genie Ops Object for IOS - CLI.
'''
from ..iosxe.lldp import Lldp as LldpXE

class Lldp(LldpXE):
    pass