# Genie
from genie.ops.base import Base


class Acl(Base):
    exclude = []