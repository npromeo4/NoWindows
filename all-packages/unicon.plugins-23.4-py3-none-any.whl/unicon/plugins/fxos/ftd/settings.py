__author__ = "dwapstra"

from ..settings import FxosSettings


class FtdSettings(FxosSettings):
    """" Generic platform settings """
    def __init__(self):
        """ initialize
        """
        super().__init__()
