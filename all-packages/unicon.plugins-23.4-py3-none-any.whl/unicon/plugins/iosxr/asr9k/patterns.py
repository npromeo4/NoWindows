from unicon.plugins.iosxr.patterns import IOSXRPatterns


class IOSXRAsr9kPatterns(IOSXRPatterns):
    pass
