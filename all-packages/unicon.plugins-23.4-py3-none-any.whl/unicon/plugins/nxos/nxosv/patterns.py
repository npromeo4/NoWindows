from ..patterns import NxosPatterns

class NxosvPatterns(NxosPatterns):
    def __init__(self):
        super().__init__()
