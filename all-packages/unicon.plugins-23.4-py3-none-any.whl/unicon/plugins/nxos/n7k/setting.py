__author__ = 'Dave Wapstra <dwapstra@cisco.com>'

from unicon.plugins.nxos.setting import NxosSettings


class Nxos7kSettings(NxosSettings):

    def __init__(self):
        super().__init__()
