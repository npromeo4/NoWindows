from .simple import SimpleInventory

__all__ = ("SimpleInventory",)
