""" File utils base class for TFTP on NXOS devices. """

from ..fileutils import FileUtils as FileUtilsNXBase

class FileUtils(FileUtilsNXBase):
	pass
