""" File utils base class for HTTP on IOS devices. """

from ...iosxe.http.fileutils import FileUtils as FileUtilsXEBase

class FileUtils(FileUtilsXEBase):
    pass
