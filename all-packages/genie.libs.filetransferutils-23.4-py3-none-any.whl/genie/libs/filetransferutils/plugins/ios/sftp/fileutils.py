""" File utils base class for SFTP on IOS devices. """

from ...iosxe.sftp.fileutils import FileUtils as FileUtilsXEBase

class FileUtils(FileUtilsXEBase):
	pass
