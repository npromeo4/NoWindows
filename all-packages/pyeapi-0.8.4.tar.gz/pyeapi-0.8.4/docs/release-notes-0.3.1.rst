######
v0.3.1
######

2015-06-14

- make pyeapi compatible under Python 3.4 with all unit tests passing ok
- added socket_error property to connection to capture socket errors
- adds function to create per vlan vtep flood lists
