######
v0.2.2
######

2015-04-15

- fixes an issue with eAPI error messages that do not return a data key
