Python Client for eAPI
======================

Full [release notes] [rns] hosted at readthedocs


[rns]: http://pyeapi.readthedocs.org/en/master/release-notes.html
