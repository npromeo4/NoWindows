
__all__ = (
        'MulticastGroup',
        )

from genie.conf.base import Base


class MulticastGroup(Base):

    def __init__(self):
        raise NotImplementedError

